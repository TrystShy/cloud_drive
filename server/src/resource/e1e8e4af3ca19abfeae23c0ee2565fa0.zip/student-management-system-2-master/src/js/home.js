$(function () {
    $(".local").text(getLocalDate('yyyy-MM-dd hh:mm:ss', new Date()))
    setInterval(_ => {
        $(".local").text(getLocalDate('yyyy-MM-dd hh:mm:ss', new Date()))
    }, 1000)
    $("#login-out").on("click", _ => {
        // 退出登录
        // 清空存储的状态loginState
        sessionStorage.clear()
        // 跳转网页
        window.location.href = 'login.html'
    })
})
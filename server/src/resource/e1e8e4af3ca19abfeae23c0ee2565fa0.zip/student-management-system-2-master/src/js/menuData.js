let menuData = [{
        icon: ' iconfont icon-jiaoshiguanli',
        title: '班级管理',
        parent: 1,
        children: [{
            icon: '',
            title: '添加班级',
            url: './view/AddClass.html',
            parent: 10
        }, {
            icon: '',
            title: '班级列表',
            url: './view/ClassList.html',
            parent: 11
        }]
    },
    {
        icon: ' iconfont icon-wodexuesheng',
        title: '学生管理',
        parent: 2,
        children: [{
                icon: '',
                title: '添加学生',
                url: './view/AddStudent.html',
                parent: 20
            },
            {
                icon: '',
                title: '学生列表',
                url: './view/StudentList.html',
                parent: 21
            }
        ]
    },
    {
        icon: ' iconfont icon-jiaolian1',
        title: '教师管理',
        parent: 3,
        children: [{
                icon: '',
                title: '添加教师',
                url: './view/AddTeacher.html',
                parent: 30
            },
            {
                icon: '',
                title: '教师列表',
                url: './view/TeacherList.html',
                parent: 31
            }
        ]
    },
    {
        icon: ' iconfont icon-banjiguanli1',
        title: '分班管理',
        parent: 4,
        children: [{
            icon: '',
            title: '分配班级',
            url: './view/AllotClass.html',
            parent: 40
        }]
    }
]
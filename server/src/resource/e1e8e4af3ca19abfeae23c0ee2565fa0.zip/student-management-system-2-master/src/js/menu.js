$(function () {
    let menu
    let openState = true
    class Menu {
        constructor(data) {
            this.data = data
            this.menuElement = document.querySelector('.menu');
            this.init()
        }
        // 初始化方法
        init() {
            // 将数据渲染到页面上
            this.render()
            // 添加事件
            this.addEvent()
        }
        // 将数据渲染到页面上
        render() {
            // 创建一个变量，接收动态的html
            let html = ''
            // 根据外部提供的data，动态生成二级列表菜单
            this.data.forEach((item, index) => {
                html += `
                <div class="dis-bar"><i class="left-bar ${item.icon}"></i></div>
                <li class="menu-item">
                    <div class="menu-item-box">
                    
                        <i class="left-bar ${item.icon}"></i>${item.title}<i class="iconfont icon-arrow-right-copy-copy right-bar"></i>
                    </div>
                    <ul class="child-menu">`
                item.children.forEach((child, i) => {
                    html += `<a class="child-item" href="javascript:void(0)" onclick="forward('${child.url}')" target="card"><li class="child-menu-item"><p>${child.title}</p></li></a>`
                })
                html += `</ul></li>`
            })
            // 将生成的html添加到.menu中
            this.menuElement.innerHTML = html
        }
        // 添加事件
        addEvent() {
            // 获取到所有的span元素，并且绑定单击事件
            $(".menu-item-box").click(function () {
                // 点击一级列表，当前一级列表对应的二级列表展开，其他一级列表对应的二级列表全部关闭
                $(this).next().stop().slideToggle(500).parent().siblings().children('ul').stop().slideUp(500)
                // 让所有的箭头向右
                $(this).parent().parent().children('li').children('.menu-item-box').children('.right-bar').removeClass('hover-down').addClass('hover-up');
                // 如果当前点击的li对应的二级列表是隐藏的，就让箭头指向 下面
                if (parseInt($(this).parent().children('.child-menu').css('height')) > 0) {
                    $(this).children('.right-bar').removeClass('hover-down').addClass('hover-up')
                } else {// 如果当前点击的li对应的二级列表是显示的，就让剪头指向 右面
                    $(this).children('.right-bar').removeClass('hover-up').addClass('hover-down')
                }
            })
            $('.shift').click(_ => {
                this.menuAnimate()
            })

            $(".dis-bar").on("click", function () {
                $('.shift').click()
            })
        }
        // menu框的展开与收缩动画
        menuAnimate() {
            if (openState) {
                $(this).removeClass('icon-daohangshouqi-').addClass('icon-caidanzhankai')
                $(".container-menu h3").stop().hide()
                $(".menu-item").hide()
                $(".dis-bar").fadeIn()
                $(".container-menu").stop().animate({
                    width: 60
                })
                openState = false
            } else {
                $(this).removeClass('icon-caidanzhankai').addClass('icon-daohangshouqi-')
                $(".dis-bar").hide()
                $(".container-menu").stop().animate({
                    width: 200
                }, 300, "linear", function () {
                    $(".container-menu img,h3").fadeIn(500, "linear")
                    $(".menu-item").fadeIn(500, "linear")
                })
                openState = true
            }
        }
    }
    menu = new Menu(menuData)
})
// 定义一个二级列表菜单跳转的函数 targetHref:跳转网页的地址
function forward(targetHref) {
    // 获取要显示跳转网页的iframe
    let iframe = parent.document.querySelector('#tabFrame')
    // 设置src
    iframe.src = targetHref
}




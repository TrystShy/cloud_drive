$(function () {
    class addClass {
        constructor() {
            this.saveBtn = $("#savebtn")
            this.className = $("#className")
            this.classNum = $("#classNum")
            this.notes = $("#notes")
            this.init()
        }
        // 初始化方法
        init() {
            // 事件监听
            this.addEvents()
        }
        // 事件监听
        addEvents() {
            this.saveBtn.on("click",_=> {
                if (this.noEmptyCheck()) {
                    // 请求后端服务器
                    this.requestHttp()
                }
            })    
        }
        // 非空校验
        noEmptyCheck() {
            if (!this.className || this.className.val() == '') {
                bootoast({
                    message: '班级名称不能为空！',
                    position: 'top',
                    type: 'danger',
                    timeout: 2
                })
                return false
            }
            if (!this.classNum || this.classNum.val() == '') {
                bootoast({
                    message: '班级人数不能为空！',
                    position: 'top',
                    type: 'danger',
                    timeout: 2
                })
                return false
            }
            if (!this.notes || this.notes.val() == '') {
                bootoast({
                    message: '备注信息不能为空！',
                    position: 'top',
                    type: 'danger',
                    timeout: 2
                })
                return false
            }
            return true
        }
        // 请求后端服务器
        requestHttp() {
            let that = this
            $.ajax({
                url: `${API.host}/ClassController/add`,
                type: 'POST',
                data: {
                    cname: this.className.val(),
                    cnumber: this.classNum.val(),
                    remark: this.notes.val()
                },
                timeout: 10000,
                success(res) {
                    console.log('添加班级-后端服务器响应结果：', res, typeof res);
                    if (res) {// 班级信息添加成功
                        // 清空表单数据
                        that.clearForm()

                        bootoast({
                            message: '班级信息添加成功！',
                            position: 'top',
                            type: 'success',
                            timeout: 2
                        })
                        // 2秒后自动跳转班级列表界面
                        setTimeout(() => {
                            window.location.href = "ClassList.html"
                        }, 2000)
                    } else {// 班级信息添加失败
                        bootoast({
                            message: '班级信息添加失败！',
                            position: 'top',
                            type: 'danger',
                            timeout: 2
                        })
                    }
                },
                error(err) {
                    bootoast({
                        message: '班级信息添加失败！',
                        position: 'top',
                        type: 'danger',
                        timeout: 2
                    })
                    throw new Error('【添加班级】服务器请求失败！ ' + err)
                }
            })
        }
        // 清空表单数据
        clearForm() {
            this.className.val('')
            this.classNum.val('')
            this.notes.val('')
        }
    }
    new addClass()
})
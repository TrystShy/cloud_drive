document.querySelector('head').innerHTML = `
<link rel="stylesheet" href="./src/css/reset.css">
<link rel="stylesheet" href="./static/css/bootstrap.min.css">
<link rel="stylesheet" href="./src/less/login.css">
`
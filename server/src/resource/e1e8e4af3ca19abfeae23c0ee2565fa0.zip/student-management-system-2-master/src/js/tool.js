// window.addEventListener('load', function () {

// })

/**
 * 获取随机数
 * @param {Number} min 最小值
 * @param {Number} max 最大值
 * @returns 
 */
function getRandom(min, max) {
    return Math.floor(Math.random() * (max - min + 1) + min)
}


/**
 * 封装自己的获取元素属性函数  dom对象 属性 伪元素
 * @param {object} dom dom对象
 * @param {string} string 属性
 * @param {string} string 伪元素
 * @returns 无
 */
function getStyle(dom, attr, str) {
    // IE9+以及主流浏览器使用   
    if (window.getComputedStyle) {
        // 判断形参str的值是否为undefined
        if (str === undefined) {
            str = null
        }
        return window.getComputedStyle(dom, str)[attr]
    } else {
        return dom.currentStyle[attr]
    }
}

/**
 * 获取滚动距离
 * @prams 无
 * @returns 滚动的距离
 */
function getScroll() {
    return {
        left: window.pageXOffset || document.documentElement.scrollLeft || document.body.scrollLeft,
        top: window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop
    }
}


/**
 * 封装一个获取DOM对象的函数
 * @param {*} cssSelector css选择器
 * @returns 
 */
/* function $(cssSelector) {
    var dom = document.querySelectorAll(cssSelector);
    if (dom.length === 0) {
        return null;
    } else if (dom.length === 1) {
        return dom[0];
    } else {
        return dom;
    }
} */


/**
 * 封装自己的缓慢动画函数
 * @param {object} dom 要做动画dom对象
 * @param {object} obj 哪些CSS属性要做动画
 * @param {function} callback 所有属性的动画完成以后,调用的回调函数
 * @returns 无
 */
function animate(dom, obj, callback) {
    window.clearInterval(dom.timer)
    dom.timer = window.setInterval(function () {
        var flag = true
        for (var attr in obj) {
            if (attr == 'z-index' || attr == 'zIndex') {
                dom.style[attr] = obj[attr]
            } else if (attr == 'opacity') {
                var target = obj[attr] * 1000
                var currentValue = parseFloat(getStyle(dom, attr)) * 1000
                var steep = (target - currentValue) / 10
                steep = steep > 0 ? Math.ceil(steep) : Math.floor(steep)
                dom.style[attr] = (currentValue + steep) / 1000
                if (target != currentValue) {
                    flag = false
                }
            } else {
                var target = obj[attr]
                var currentValue = parseInt(getStyle(dom, attr))
                var steep = (target - currentValue) / 10
                steep = steep > 0 ? Math.ceil(steep) : Math.floor(steep)
                dom.style[attr] = currentValue + steep + 'px'
                if (target != currentValue) {
                    flag = false
                }
            }
            if (flag) {
                window.clearInterval(dom.timer)
                if (typeof callback === 'function') {
                    callback()
                }
            }
        }
    }, 15)
}


/**
   * 函数防抖
   * @param {object} func 目标函数
   * @param {Number} wait 延迟执行毫秒数
   * @param {boolean} immediate true - 立即执行， false - 延迟执行
   */
function debounce(func, wait, immediate) {
    var timer, context, args
    return function () {
        context = this
        args = arguments
        clearTimeout(timer)
        if (immediate) {
            var callNow = !timer
            timer = setTimeout(function () {
                timer = null
            }, wait)
            if (callNow) {
                func.apply(context, args)
            }
        } else {
            timer = setTimeout(function () {
                func.apply(context, args)
            }, wait)
        }
    }
}
/**
 * 函数节流时间戳与定时器合并
 * @param {Object} func 
 * @param {Number} wait 
 * @returns 
 */
function throttle(func, wait) {
    var previous = 0
    var context = null
    var args = null
    var timer = null
    return function () {
        context = this
        args = arguments
        var now = new Date().getTime()
        if (now - previous > wait) {
            func.apply(context, args)
            previous = now
            if (timer) {
                clearTimeout(timer)
                timer = null
            }
        }
        if (!timer) {
            timer = setTimeout(function () {
                func.apply(context, args)
                timer = null
                now = new Date().getTime()
                previous = now
            }, wait)
        }
    }
}


/**
 * promise方式的ajax函数
 * @param {String} url 
 * @returns {Object}
 */
function sendAjax(url) {
    return new Promise(function (resolve, reject) {
        let xhr = new XMLHttpRequest();
        xhr.open("GET", url);
        xhr.send();
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4) {
                if (xhr.status === 200) {
                    // 成功状态,返回终值
                    resolve(JSON.parse(xhr.responseText));
                } else {
                    // 失败状态,返回据因
                    reject("ajax请求失败");
                }
            }
        }
    })
}

/**
 * 生成格式化日期
 * @param {*} templatel：默认 yyyy-MM-dd hh:mm:ss 星期*
 * @param {*} date 
 * @returns 
 */
function getLocalDate(templatel, date) {
    if (/y+/.test(templatel)) {
        templatel = templatel.replace(/y+/g, function (match) {
            return (date.getFullYear() + "").substr(4 - match.length)
        })
    }
    var o = {
        'M+': date.getMonth() + 1,
        'd+': date.getDate(),
        'h+': date.getHours(),
        'm+': date.getMinutes(),
        's+': date.getSeconds()
    }
    for (var k in o) {
        var reg = new RegExp(k, 'g');
        if (reg.test(templatel)) {
            var time = o[k] + '';
            templatel = templatel.replace(reg, function (match) {
                return (match.length === 1) ? time : ('00' + time).substr(time.length);
            })
        }
    }
    // 生成星期
    let weekIndex = date.getDay() // 0~6
    let weeks = ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六']
    return templatel + ' ' + weeks[weekIndex]
}
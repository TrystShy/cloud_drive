$(function () {
    class Login {
        constructor() {
            this.loginBtn = $('#login_btn')
            this.usernameEl = $('#username')
            this.passwordEl = $('#password')
            this.init()
        }
        // 初始化方法
        init() {
            // 事件监听方法
            this.addEvents()
            //校验用户名
            this.checkUserName()
            //校验密码
            this.checkPassword()
            //密码显示隐藏
            this.checkPasswordShow()
            // 登录自动后将数据保存到localStorage
            this.pageLoad()
        }
        //校验用户名
        checkUserName() {
            $("#username").on({
                "blur": function () {
                    if ($(this).val().trim().length == 0) {
                        return
                    }
                    if (/^[a-zA-Z0-9_-]{4,16}$/.test($(this).val())) {
                        $(".check_user").slideUp()
                    } else {
                        $(".check_user").slideDown()
                    }
                },
                "focus": function () {
                    $(".check_user").slideUp()
                }
            }
            )
        }
        //校验密码
        checkPassword() {
            $("#password").on({
                "blur": function () {
                    if ($(this).val().trim().length == 0) {
                        return
                    }
                    if (/^[A-Za-z0-9]{6,12}$/.test($(this).val())) {
                        $(".check_psw").slideUp()
                    } else {
                        $(".check_psw").slideDown()
                    }
                },
                "focus": function () {
                    $(".check_psw").slideUp()
                }
            }
            )
        }
        //密码显示隐藏
        checkPasswordShow() {
            let flag = true
            $("#eye").on("click", function () {
                if (flag) {
                    $(this).removeClass("icon-yanjing1").addClass("icon-yanjing")
                    $("#password").prop("type", "text")
                    flag = false
                } else {
                    $(this).removeClass("icon-yanjing").addClass("icon-yanjing1")
                    $("#password").prop("type", "password")
                    flag = true
                }
            })
        }
        // 事件监听方法
        addEvents() {
            let that = this
            // 给登录按钮绑定点击事件
            this.loginBtn.click(function () {
                // 非空校验
                if (that.noEmptyCheck()) {
                    // 请求后端服务器
                    that.requestHttp()
                }
                // 存储密码
                that.save_pass()
            })
        }
        // 非空校验方法
        noEmptyCheck() {
            // 校验用户名
            if (!this.usernameEl.val() || this.usernameEl.val() == '') {
                bootoast({
                    message: '用户名不能为空！',
                    position: 'top',
                    type: 'danger',
                    timeout: 1
                });
                return false
            }
            // 校验密码
            if (!this.passwordEl.val() || this.passwordEl.val() == '') {
                bootoast({
                    message: '用户密码不能为空！',
                    position: 'top',
                    type: 'danger',
                    timeout: 1
                })
                return false
            }
            return true
        }
        // 请求后端服务器
        requestHttp() {
            $.ajax({
                url: `${API.host}/login`,
                type: 'POST',
                data: `username=${this.usernameEl.val()}&password=${this.passwordEl.val()}`,
                timeout: 10000,
                success(res) {
                    console.log('登录-后端服务器响应结果：', res, typeof res);
                    if (res == 'success') {// 用户登录成功
                        bootoast({
                            message: '用户登录成功！',
                            position: 'top',
                            type: 'success',
                            timeout: 1
                        })
                        // 登录成功，就去记录登录成功的状态
                        sessionStorage.setItem('loginState', res)
                        // 延时两秒，自动跳转到Home.html
                        setTimeout(() => {
                            window.location.href = "Home.html"
                        }, 1000)
                    } else {// 用户登录失败
                        bootoast({
                            message: '用户登录失败！',
                            position: 'top',
                            type: 'danger',
                            timeout: 1
                        })
                    }
                },
                error(err) {
                    bootoast({
                        message: '用户登录失败！',
                        position: 'top',
                        type: 'danger',
                        timeout: 1
                    })
                    throw new Error('【用户登录】服务器请求失败！ ' + err)
                }
            })
        }
        
        // 登录自动后将数据保存到localStorage
        save_pass() {
            let strName = $("#username").val()
            let strPass = $("#password").val()
            localStorage.setItem("keyName", strName)
            //如果选择保存密码
            if ($("#customSwitch1").prop("checked")) {
                //系统存储密码，否则移除
                localStorage.setItem("keyPass", strPass)
            } else {
                localStorage.removeItem("keyPass");
            }
        }
        // 点击登录后将localStorage值存储到文本框
        pageLoad() {
            let strName = localStorage.getItem("keyName")
            let strPass = localStorage.getItem("keyPass")
            //判断，如果输入的值等于存储的值
            if (strName) {
                $("#username").val(strName)
            }
            if (strPass) {
                $("#password").val(strPass)
            }
        }
    }
    new Login()
})

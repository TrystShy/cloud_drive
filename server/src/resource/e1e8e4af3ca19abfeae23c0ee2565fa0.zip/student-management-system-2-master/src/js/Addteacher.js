$(function () {
    class addTeacher {
        constructor() {
            this.saveBtn = $("#savebtn")
            this.tnameEl = $('#tname')
            this.tsexEl = $('#tsex')
            this.tnumEl = $('#tnum')
            this.tsubEl = $('#tsub')
            this.remarkEl = $('#remark')
            this.init()
        }
        // 初始化方法
        init() {
            // 事件监听
            this.addEvents()
        }
        // 事件监听
        addEvents() {
            this.saveBtn.on("click", _ => {
                if (this.noEmptyCheck()) {
                    // 请求后端服务器
                    this.requestHttp()
                }
            })
        }
        // 非空校验
        noEmptyCheck() {
            if (!this.tnameEl || this.tnameEl.val() == '') {
                bootoast({
                    message: '教师名称不能为空！',
                    position: 'top',
                    type: 'danger',
                    timeout: 2
                })
                return false
            }
            if (!this.tsexEl || this.tsexEl.val() == '') {
                bootoast({
                    message: '教师性别不能为空！',
                    position: 'top',
                    type: 'danger',
                    timeout: 2
                })
                return false
            }
            if (!this.tnumEl || this.tnumEl.val() == '') {
                bootoast({
                    message: '教师身份证号不能为空！',
                    position: 'top',
                    type: 'danger',
                    timeout: 2
                })
                return false
            }
            if (!this.tsubEl || this.tsubEl.val() == '') {
                bootoast({
                    message: '教授科目不能为空！',
                    position: 'top',
                    type: 'danger',
                    timeout: 2
                })
                return false
            }
            return true
        }
        // 请求后端服务器
        requestHttp() {
            let that = this
            let data = {
                tname: this.tnameEl.val(),
                tsex: this.tsexEl.val(),
                tnum: this.tnumEl.val(),
                tsub: this.tsubEl.val(),
                remark: this.remarkEl.val()
            }
            $.ajax({
                url: `${API.host}/TeacherController/add`,
                type: 'POST',
                data: data,
                timeout: 10000,
                success(res) {
                    console.log('添加教师-后端服务器响应结果：', res, typeof res);
                    if (res) {// 教师信息添加成功
                        // 清空表单数据
                        that.clearForm()

                        bootoast({
                            message: '教师信息添加成功！',
                            position: 'top',
                            type: 'success',
                            timeout: 2
                        })
                        // 2秒后自动跳转教师列表界面
                        setTimeout(() => {
                            window.location.href = "TeacherList.html"
                        }, 1000)
                    } else {// 教师信息添加失败
                        bootoast({
                            message: '教师信息添加失败！',
                            position: 'top',
                            type: 'danger',
                            timeout: 2
                        })
                    }
                },
                error(err) {
                    bootoast({
                        message: '教师信息添加失败！',
                        position: 'top',
                        type: 'danger',
                        timeout: 2
                    })
                    throw new Error('【添加教师】服务器请求失败！ ' + err)
                }
            })
        }
        // 清空表单数据
        clearForm() {
            this.tnameEl.val('')
            this.tsexEl.val('')
            this.tnumEl.val('')
            this.tsubEl.val('')
            this.remarkEl.val('')
        }
    }
    new addTeacher()
})
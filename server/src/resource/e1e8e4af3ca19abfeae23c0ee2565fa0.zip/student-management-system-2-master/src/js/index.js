export default class ImportStudent {
    constructor() {
        // 批量导入
        this.selectFileBtn = $('#selectFile')// 选择文件的按钮
        this.fileInputEl = $('#lefile')// 这个是本来的文件选择框，因为太丑，隐藏
        this.fileCoverEl = $('#fileCover')// 这个是文本框，用来显示选中文件的名字，这个只是为了UI好看，实质上用的还是file输入框
        this.downloadBtn = $('#downloadBtn')// 下载模板按钮
        this.importFileBtn = $('#importFile')// 批量导入的按钮
        this.init()
    }
    init() {
        addEvents()
    }
    addEvents(address) {
        // 选择上传模板（文件）
        // 选择上传模板（文件）
        this.selectFileBtn.click(function () {
            // 触发文件选择框的事件
            that.fileInputEl.click()
        })
        // 监听文件选择框的change事件
        this.fileInputEl.change(function () {
            // 将file输入框的val，取出来赋值给text输入框
            that.fileCoverEl.val(that.fileInputEl.val())
        })
        // 给下载模板按钮绑定事件
        this.downloadBtn.click(function () {
            // 给a标签绑定href
            $(this).prop('href', `${API.host}/ClassController/downloadTemplates`)
        })
        // 上传文件（批量导入）
        this.importFileBtn.click(function () {
            // 文件通过FormData上传
            let formDataObj = new FormData();
            let file = that.fileInputEl[0].files[0]
            if (file == null) {
                bootoast({
                    message: '文件不能为空！',
                    type: 'danger',
                    position: 'top',
                    timeout: 2
                })
            } else {
                // 将文件添加到FormData
                formDataObj.append('file', file)
                // 发起服务端请求
                $.ajax({
                    url: `${API.host}/${address}Controller/upload`,
                    type: 'POST',
                    data: formDataObj,// 直接将对象放在data后面
                    // 文件上传需要指明以下两个参数
                    contentType: false,// 不使用任务编码，formdata对象能够自动解析
                    processData: false,// 告诉浏览器不要对当前数据做任何处理
                    success(res) {
                        if (res) {
                            res = JSON.parse(res)
                            if (res.flag === 'true') {// 文件上传成功
                                let msg = `成功导入数据：${res.addRows}行<br>更新数据：${res.updateRows}行<br>错误数据所在的行：${res.errorRows}`
                                // 模态框展示
                                $('#msg').html(msg)
                                $('#importSuccess').modal('show')
                                // 刷新列表数据
                                that.requestHttp()
                            } else {
                                bootoast({
                                    message: '文件导入失败！',
                                    type: 'danger',
                                    position: 'top',
                                    timeout: 2
                                })
                            }
                        } else {
                            bootoast({
                                message: '文件导入失败！',
                                type: 'danger',
                                position: 'top',
                                timeout: 2
                            })
                        }
                    },
                    error(err) {
                        bootoast({
                            message: '服务器请求错误！',
                            type: 'danger',
                            position: 'top',
                            timeout: 2
                        })
                    }
                })
            }
        })
    }

}


$(function () {
    class TeacherList {
        constructor() {
            this.keywordsEl = $('#keywords')
            this.searchBtn = $('.search')
            this.paginationUl = $('.pagination')
            this.saveBtn = $('#save')
            this.deleteBtn = $('#delete')
            // 表单元素
            this.tidEl = $('#tid')
            this.tnameEl = $('#tname')
            this.tsexEl = $('#tsex')
            this.tnumEl = $('#tnum')
            this.tsubEl = $('#tsub')
            this.remarkEl = $('#remark')

            // 批量导入
            this.selectFileBtn = $('#selectFile')// 选择文件的按钮
            this.fileInputEl = $('#lefile')// 这个是本来的文件选择框，因为太丑，隐藏
            this.fileCoverEl = $('#fileCover')// 这个是文本框，用来显示选中文件的名字，这个只是为了UI好看，实质上用的还是file输入框
            this.downloadBtn = $('#downloadBtn')// 下载模板按钮
            this.importFileBtn = $('#importFile')// 批量导入的按钮

            this.pageNum = 1 // 当前页码
            this.pageCount = 5 // 每页显示的条数

            // 删除所需
            this.tid = 0
            this.tag = null // 'all':清空数据，'one':删除单条信息
            this.init()
        }
        // 初始化方法
        init() {
            // 数据渲染的方法
            this.render()
            // 事件监听方法
            this.addEvents()
            // 模态框的方法
            this.initModal()
        }
        // 数据渲染的方法
        render(res) {
            // 访问后台服务器
            this.requestHttp()
        }
        // 模态框的方法
        initModal() {
            // 修改操作  模态框显示的时候，自动执行
            $('#updateClassModal').on('show.bs.modal', function (event) {
                // 获取按钮上携带的数据(data-*)
                let button = $(event.relatedTarget)
                let tid = button.data('tid')
                let tname = button.data('tname')
                let tsex = button.data('tsex')
                let tnum = button.data('tnum')
                let tsub = button.data('tsub')
                let remark = button.data('remark')
                // 获取模态框上的组件
                var modal = $(this)
                modal.find('#tid').val(tid)
                modal.find('#tname').val(tname)
                modal.find('#tsex').val(tsex)
                modal.find('#tnum').val(tnum)
                modal.find('#tsub').val(tsub)
                modal.find('#remark').val(remark)
            })
            // 删除操作  模态框显示的时候，自动执行 
            $('#deleteClassModal').on('show.bs.modal', _ => {
                // 获取触发模态框的按钮（编辑）
                let button = $(_.relatedTarget)
                // 获取按钮上携带的数据(data-*)
                this.tid = button.data('tid')
                this.tag = button.data('tag')
            })
        }
        // 事件监听方法
        addEvents() {
            let that = this
            // 给搜索按钮绑定事件
            this.searchBtn.click(function () {
                // 访问后台数据
                that.requestHttp()
            })
            // 给分页组件绑定事件
            this.paginationUl.on('click', 'a', function (e) {
                if (this.nodeName == 'A') {
                    // 获取当前页
                    that.pageNum = $(this).attr('data-current-page')
                    // 获取a标签携带的页码
                    let page = $(this).attr('data-page')
                    // 处理上一页，或者下一页
                    let isPage = $(this).attr('data-tag')
                    if (isPage == 'prev') {// 上一页
                        if (that.pageNum > 1) {
                            that.pageNum = that.pageNum - 1
                        }
                    } else if (isPage == 'next') {// 下一页
                        // 获取最大页码
                        let maxPageNum = $(this).attr('data-total')
                        if (that.pageNum < maxPageNum) {
                            that.pageNum = parseInt(that.pageNum) + 1
                        }
                    } else {// 数字页
                        that.pageNum = page
                    }
                    // 访问后台数据
                    that.requestHttp()
                }
            })
            // 给模态框上的保存按钮修改事件
            // 修改教师信息
            this.saveBtn.click(function () {
                // 非空校验
                if (that.noEmptyCheck()) {
                    // 执行修改操作
                    that.save()
                }
            })
            // 删除教师信息
            this.deleteBtn.click(function () {
                // 默认是删除单条信息
                let url = `${API.host}/TeacherController/delOne`
                let data = {
                    tid: that.tid
                }
                // 清空数据
                if (that.tag == 'all') {// 清空数据
                    url = `${API.host}/TeacherController/delAll`
                    data = {}
                }
                // 请求服务器删除数据
                $.ajax({
                    url: url,
                    type: 'POST',
                    data: data,
                    timeout: 10000,
                    success(res) {
                        console.log('删除教师-后端服务器响应结果：', res, typeof res);
                        if (res) {// 教师信息修改成功
                            // 消息提示
                            bootoast({
                                message: '教师信息删除成功！',
                                position: 'top',
                                type: 'success',
                                timeout: 1
                            })
                            // 关闭模态框
                            $('#deleteClassModal').modal('hide')
                            // 刷新数据
                            that.requestHttp()
                        } else {// 教师信息修改失败
                            bootoast({
                                message: '教师信息删除失败！',
                                position: 'top',
                                type: 'danger',
                                timeout: 1
                            })
                        }
                    },
                    error(err) {
                        bootoast({
                            message: '教师信息删除失败！',
                            position: 'top',
                            type: 'danger',
                            timeout: 1
                        })
                        throw new Error('【删除教师】服务器请求失败:' + err)
                    }
                })
            })
            // 选择上传模板（文件）
            // 选择上传模板（文件）
            this.selectFileBtn.click(function () {
                // 触发文件选择框的事件
                that.fileInputEl.click()
            })
            // 监听文件选择框的change事件
            this.fileInputEl.change(function () {
                // 将file输入框的val，取出来赋值给text输入框
                that.fileCoverEl.val(that.fileInputEl.val())
            })
            // 给下载模板按钮绑定事件
            this.downloadBtn.click(function () {
                // 给a标签绑定href
                $(this).prop('href', `${API.host}/TeacherController/downloadTemplates`)
            })
            // 上传文件（批量导入）
            this.importFileBtn.click(function () {
                // 文件通过FormData上传
                let formDataObj = new FormData();
                let file = that.fileInputEl[0].files[0]
                if (file == null) {
                    bootoast({
                        message: '文件不能为空！',
                        type: 'danger',
                        position: 'top',
                        timeout: 2
                    })
                } else {
                    // 将文件添加到FormData
                    formDataObj.append('file', file)
                    // 发起服务端请求
                    $.ajax({
                        url: `${API.host}/TeacherController/upload`,
                        type: 'POST',
                        data: formDataObj,// 直接将对象放在data后面
                        // 文件上传需要指明以下两个参数
                        contentType: false,// 不使用任务编码，formdata对象能够自动解析
                        processData: false,// 告诉浏览器不要对当前数据做任何处理
                        success(res) {
                            if (res) {
                                res = JSON.parse(res)
                                if (res.flag === 'true') {// 文件上传成功
                                    let msg = `成功导入数据：${res.addRows}行<br>更新数据：${res.updateRows}行<br>错误数据所在的行：${res.errorRows}`
                                    // 模态框展示
                                    $('#msg').html(msg)
                                    $('#importSuccess').modal('show')
                                    // 刷新列表数据
                                    that.requestHttp()
                                } else {
                                    bootoast({
                                        message: '文件导入失败！',
                                        type: 'danger',
                                        position: 'top',
                                        timeout: 2
                                    })
                                }
                            } else {
                                bootoast({
                                    message: '文件导入失败！',
                                    type: 'danger',
                                    position: 'top',
                                    timeout: 2
                                })
                            }
                        },
                        error(err) {
                            bootoast({
                                message: '服务器请求错误！',
                                type: 'danger',
                                position: 'top',
                                timeout: 2
                            })
                        }
                    })
                }
            })
        }
        // 非空校验
        noEmptyCheck() {
            if (!this.tnameEl || this.tnameEl.val() == '') {
                bootoast({
                    message: '姓名不能为空！',
                    position: 'top',
                    type: 'danger',
                    timeout: 2
                })
                return false
            }
            if (!this.tsexEl || this.tsexEl.val() == '') {
                bootoast({
                    message: '性别不能为空！',
                    position: 'top',
                    type: 'danger',
                    timeout: 2
                })
                return false
            }
            if (!this.tsubEl || this.tsubEl.val() == '') {
                bootoast({
                    message: '身份证号不能为空！',
                    position: 'top',
                    type: 'danger',
                    timeout: 2
                })
                return false
            }
            if (!this.tsubEl || this.tsubEl.val() == '') {
                bootoast({
                    message: '教授科目不能为空！',
                    position: 'top',
                    type: 'danger',
                    timeout: 2
                })
                return false
            }
            return true

        }
        // 修改教师信息：（请求后端服务器）
        save() {
            let that = this
            let data = {
                tid: this.tidEl.val(),
                tname: this.tnameEl.val(),
                tsex: this.tsexEl.val(),
                tnum: this.tnumEl.val(),
                tsub: this.tsubEl.val(),
                remark: this.remarkEl.val()
            }
            $.ajax({
                url: `${API.host}/TeacherController/update`,
                type: 'POST',
                data: data,
                timeout: 10000,
                success(res) {
                    console.log('修改教师-后端服务器响应结果：', res, typeof res);
                    if (res) {// 教师信息修改成功
                        // 消息提示
                        bootoast({
                            message: '教师信息修改成功！',
                            position: 'top',
                            type: 'success',
                            timeout: 1
                        })
                        // 关闭模态框
                        $('#updateClassModal').modal('hide')
                        // 刷新数据
                        that.requestHttp()
                    } else {// 教师信息修改失败
                        bootoast({
                            message: '教师信息修改失败！',
                            position: 'top',
                            type: 'danger',
                            timeout: 1
                        })
                    }
                },
                error(err) {
                    bootoast({
                        message: '教师信息修改失败！',
                        position: 'top',
                        type: 'danger',
                        timeout: 1
                    })
                    throw new Error('【修改教师】服务器请求失败！ ' + err)
                }
            })
        }
        // 访问后台服务器
        requestHttp() {
            let that = this
            $.ajax({
                url: `${API.host}/TeacherController/findAll?condition=${that.keywordsEl.val()}&pageNum=${that.pageNum}&pageCount=${that.pageCount}`,
                type: "GET",
                timeout: 10000,
                success(res) {
                    console.log('教师列表-后端服务器响应结果：', res, typeof res);
                    if (res) {
                        // 查询到数据页面渲染
                        that.addPage(res)
                    } else {
                        bootoast({
                            message: '教师信息获取失败！',
                            position: 'top',
                            type: 'danger',
                            timeout: 1
                        })
                        // 未查询到数据页面渲染
                        that.emptyData()
                    }
                },
                error(err) {
                    that.emptyData()
                    bootoast({
                        message: '教师信息获取失败！',
                        position: 'top',
                        type: 'danger',
                        timeout: 1
                    })
                    throw new Error('【教师列表】服务器请求失败！ ' + err)
                }
            })
        }
        // 查询到数据页面渲染
        addPage(res) {
            let that = this
            // 将JSON字符串转换为object
            res = JSON.parse(res)
            console.log(res.pageList.length > 0)
            if (res.pageList && res.pageList.length > 0) {
                $('.card-body p').empty()
                let html = res.pageList.map((item, index) => {
                    return `
                    <tr>
                        <td class="center">${item.tid}</td>
                        <td class="center">${item.tname}</td>
                        <td class="center">${item.tsex}</td>
                        <td class="center">${item.tnum}</td>
                        <td class="center">${item.tsub}</td>
                        <td class="center">${item.remark}</td>
                        <td class="setting center">
                        <button type="button" class="btn btn-link" data-toggle="modal" data-target="#updateClassModal" data-tid=${item.tid} data-tname=${item.tname} data-tsex=${item.tsex} data-tnum=${item.tnum} data-tsub=${item.tsub} data-remark=${item.remark}><i class="glyphicon glyphicon-edit iconfont icon-bianji"></i> 编辑</button>
                        <button type="button" class="btn btn-sm btn-danger"  data-toggle="modal" data-target="#deleteClassModal" data-tid=${item.tid} data-tag="one"><i class="glyphicon glyphicon-trash iconfont icon-guanbi"></i>   删除</button>
                        </td>
                    </tr>`
                })
                $('.table tbody').html(html)
                $('#pageCard').show(0)
                // 页码按钮生成
                var pagehtml = `<li>
                <a class="page-link" href="javascript:void(0)" aria-label="Next" data-page=${res.maxPageNum} data-tag='prev' data-total=${res.maxPageNum} data-current-page=${res.pageNum}>
                    <<
                </a>
            </li>`
                pagehtml += `<li class="page-item"><a class="page-link" href="javascript:void(0)" data-page=1 >1</a></li>`
                for (var i = 2; i <= res.maxPageNum; i++) {
                    pagehtml += `<li class="page-item"><a class="page-link" href="javascript:void(0)" data-page=${i}>${i}</a></li>`
                }
                pagehtml += `<li>
                    <a class="page-link" href="javascript:void(0)" aria-label="Next" data-page=${res.maxPageNum} data-tag='next' data-total=${res.maxPageNum} data-current-page=${res.pageNum}>
                        >>
                    </a>
                </li><li><span class="page-link" aria-hidden="true" disable>当前第${res.pageNum}页，共${res.maxPageNum}页</span></li>`
                $('.pagination').html(pagehtml)
                $('.card-body thead').show()
                $('.card-body tbody').show()
                $('#pageCard').show(0)
            } else {
                // 未查询到数据页面渲染
                $('.card-body p').html('')
                that.emptyData()

            }
        }
        // 未查询到数据页面渲染
        emptyData() {
            $('.card-body thead').hide()
            $('.card-body tbody').hide()
            $('.card-body').append('<p style="text-align:center;margin:60px 0;font-size:14px;color:#red;"><i style="color:#d7504c" class="iconfont icon-chazhaoyonghu">未查询到教师信息</i></p>')
            $('#pageCard').hide(0)
        }
    }
    new TeacherList()


})
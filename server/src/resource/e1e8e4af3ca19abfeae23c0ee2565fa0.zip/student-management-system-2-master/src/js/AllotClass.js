$(function () {
    class ClassList {
        constructor() {
            this.timeout = 10000 // 10秒
            this.keywordsEl = $('#keywords')
            this.searchBtn = $('.search')
            this.paginationUl = $('.pagination')
            this.allotBtn = $('#allot')// 分班按钮
            // 表单元素
            this.pageNum = 1 // 当前页码
            this.pageCount = 8 // 每页显示的条数        
            this.init()

        }
        // 初始化方法
        init() {
            this.render()
            this.addEvents()
        }

        // 数据渲染的方法
        render(res) {
            // 获取已经分班的学生信息
            this.queryStudents()
        }
        // 事件监听方法
        addEvents() {
            let that = this
            // 给搜索按钮绑定事件
            this.searchBtn.click(function () {
                // 每次点击完搜索按钮，就让从第一页显示
                that.pageNum = 1
                that.requestHttp()
            })
            // 点击分班按钮，进行分班操作
            this.allotBtn.click(function () {
                // 给一个10秒的提示
                bootoast({
                    message: '正在努力分班中，请稍后......',
                    position: 'top',
                    type: 'success',
                    timeout: that.timeout / 1000
                })
                // 分班操作
                setTimeout(() => {
                    that.alloClass()
                }, that.timeout / 2)


            })
            // 给分页组件绑定事件
            this.paginationUl.on('click', 'a', function (e) {
                let aEl = e.target
                if (aEl.nodeName == 'A') {
                    // 获取a标签携带的cid
                    let cid = $(aEl).attr('data-cid')
                    that.queryStudents(cid)
                }
            })
        }
        // 查询所有已经分班的学生信息
        queryStudents(cid) {
            let that = this
            if (!cid) {
                cid = 1 // cid，页码标识，班级标识
            }
            $.ajax({
                url: `${API.host}/DistributionController/SelectClassStu`,
                type: 'GET',
                data: {
                    cid: cid
                },
                timeout: that.timeout,
                success(res) {
                    console.log('已分班列表-后端服务器响应结果：', res, typeof res);
                    if (res) {// 分班信息查询成功
                        res = JSON.parse(res)
                        console.log(res)
                        // 获取班级
                        let classes = res.classes
                        // 获取已经分班的学生信息
                        let stuInfo = res.page.pageList
                        console.log(stuInfo);
                        console.log(classes);
                        if (stuInfo) {
                            // 清空表格
                            $('.class-list tbody').empty()
                            // 遍历学生信息
                            stuInfo.forEach((item, index) => {
                                $(`                           
                                    <tr>
                                        <td class="center">${item.sid}</td>
                                        <td class="center">${item.sname}</td>
                                        <td class="center">${item.snum}</td>
                                        <td class="center">${getCnameByCid(item.cid, classes)}</td >    
                                    </tr >
                                        `).appendTo($('.class-list tbody'))
                            })
                        }

                        // 处理分页
                        $('#page-box').show()
                        // 每次进来先清空ul
                        $('.pagination').empty()
                        console.log("***************", classes);
                        for (let i = 1; i <= classes.length; i++) {
                            $('.pagination').append(`<li> <a href="javascript:void(0)" data-cid=${i}>${classes[i].cname}</a></li> `)
                        }


                    } else {// 分班信息查询失败
                        that.emptyData()
                        bootoast({
                            message: '分班信息获取失败！',
                            position: 'top',
                            type: 'danger',
                            timeout: 2
                        })
                    }
                },
                error(err) {
                    that.emptyData()
                    bootoast({
                        message: '服务器请求错误！',
                        position: 'top',
                        type: 'danger',
                        timeout: 2
                    })
                    throw new Error('【分班列表】服务器请求失败！ ' + err)
                }

            })
        }
        // 分配班级
        alloClass() {
            let that = this
            $.ajax({
                url: `${API.host} /DistributionController/Distrubution`,
                type: 'GET',
                timeout: that.timeout,
                success(res) {
                    console.log('分配班级-后端服务器响应结果：', res, typeof res);
                    if (res) {
                        res = JSON.parse(res)
                        if (res.page && res.page.pageList) {// 分班成功
                            bootoast({
                                message: '班级分配成功！',
                                position: 'top',
                                type: 'success',
                                timeout: 2
                            })
                            // 获取分班信息
                            that.queryStudents()
                        } else {// 分班失败
                            bootoast({
                                message: '班级分配失败！',
                                position: 'top',
                                type: 'danger',
                                timeout: 2
                            })
                        }
                    }
                },
                error(err) {
                    bootoast({
                        message: '服务器请求错误！',
                        position: 'top',
                        type: 'danger',
                        timeout: 2
                    })
                    throw new Error('【分配班级】服务器请求失败！ ' + err)
                }
            })
        }



        emptyData() {
            $('#nullMessage').show()
            $('.class-list').hide()
            // 隐藏分页组件
            // $('.class-list thead').hide()
            // $('.class-list tbody').empty()
            // $('.class-list tbody').html('<tr><td colspan="5" style="text-align:center;padding:60px 0;font-size:14px;color:#333;"><i style="color:#d7504c" class="glyphicon glyphicon-info-sign"></i> 未查询到分班信息</td></tr>')

        }

    }
    new ClassList()

    // 通过班级编号获取班级名称
    function getCnameByCid(cid, classes) {
        if (cid && classes) {
            for (let item of classes) {
                if (item.cid == cid) {
                    return item.cname
                }
            }

        }
        return '未知';
    }
})
$(function () {
    class addStudent {
        constructor() {
            this.saveBtn = $("#savebtn")
            this.snameEl = $('#sname')
            this.ssexEl = $('#ssex')
            // this.ssexEl = $('input[name=ssex]')
            this.snumEl = $('#snum')
            this.slanEl = $('#slan')
            this.smathEl = $('#smath')
            this.senEl = $('#sen')
            this.remarkEl = $('#remark')
            this.init()
        }
        // 初始化方法
        init() {
            // 事件监听
            this.addEvents()
        }
        // 事件监听
        addEvents() {
            this.saveBtn.on("click", _ => {
                if (this.noEmptyCheck()) {
                    // 请求后端服务器
                    this.requestHttp()
                }
            })
        }
        // 非空校验
        noEmptyCheck() {
            if (!this.snameEl || this.snameEl.val() == '') {
                bootoast({
                    message: '学生名称不能为空！',
                    position: 'top',
                    type: 'danger',
                    timeout: 2
                })
                return false
            }
            if (!this.ssexEl || this.ssexEl.val() == '') {
                bootoast({
                    message: '学生性别不能为空！',
                    position: 'top',
                    type: 'danger',
                    timeout: 2
                })
                return false
            }
            if (!this.snumEl || this.snumEl.val() == '') {
                bootoast({
                    message: '学生身份证号不能为空！',
                    position: 'top',
                    type: 'danger',
                    timeout: 2
                })
                return false
            }
            if (!this.slanEl || this.slanEl.val() == '') {
                bootoast({
                    message: '语文成绩不能为空！',
                    position: 'top',
                    type: 'danger',
                    timeout: 2
                })
                return false
            }
            if (!this.smathEl || this.smathEl.val() == '') {
                bootoast({
                    message: '数学成绩不能为空！',
                    position: 'top',
                    type: 'danger',
                    timeout: 2
                })
                return false
            }
            if (!this.senEl || this.senEl.val() == '') {
                bootoast({
                    message: '英语成绩不能为空！',
                    position: 'top',
                    type: 'danger',
                    timeout: 2
                })
                return false
            }
            return true
        }
        // 请求后端服务器
        requestHttp() {
            let that = this
            let data = {
                sname: this.snameEl.val(),
                ssex: this.ssexEl.val(),
                // ssex: $('input[name=ssex]:checked').val(),
                snum: this.snumEl.val(),
                slan: this.slanEl.val(),
                smath: this.smathEl.val(),
                sen: this.senEl.val(),
                remark: this.remarkEl.val()
            }
            console.log(
                this.snameEl.val(),
                this.ssexEl.val(),
                this.snumEl.val(),
                this.slanEl.val(),
                this.smathEl.val(),
                this.senEl.val(),
                this.remarkEl.val())
            $.ajax({
                url: `${API.host}/StudentController/add`,
                type: 'POST',
                data: data,
                timeout: 10000,
                success(res) {
                    console.log('添加学生-后端服务器响应结果：', res, typeof res);
                    if (res) {// 学生信息添加成功
                        // 清空表单数据
                        that.clearForm()

                        bootoast({
                            message: '学生信息添加成功！',
                            position: 'top',
                            type: 'success',
                            timeout: 2
                        })
                        // 2秒后自动跳转学生列表界面
                        setTimeout(() => {
                            window.location.href = "StudentList.html"
                        }, 1000)
                    } else {// 学生信息添加失败
                        bootoast({
                            message: '学生信息添加失败！',
                            position: 'top',
                            type: 'danger',
                            timeout: 2
                        })
                    }
                },
                error(err) {
                    bootoast({
                        message: '学生信息添加失败！',
                        position: 'top',
                        type: 'danger',
                        timeout: 2
                    })
                    throw new Error('【添加学生】服务器请求失败！ ' + err)
                }
            })
        }
        // 清空表单数据
        clearForm() {
            this.snameEl.val('')
            this.ssexEl.val('')
            this.snumEl.val('')
            this.slanEl.val('')
            this.smathEl.val('')
            this.senEl.val('')
            this.remarkEl.val('')
        }
    }
    new addStudent()
})